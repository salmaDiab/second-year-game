package engine;
//import SecondWindow;

import java.awt.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
//import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class view extends JFrame {
	private JTextArea p1right;
	private JPanel p1left;
	private JPanel player2;
	private JPanel player1;
	private JTextArea kalamGwaya;
	//private SecondWindow p2;
	//private JButton button1;



	public view() {
	      super();
	     this.setBounds(500, 500, 1500, 1000);
	      //getContentPane().setBackground(Color.LIGHT_GRAY);
	      this.setBackground(Color.WHITE);
	      //setLayout( new BorderLayout());
	      this.setVisible(true);
	      this.setTitle("Hearthstone");
	     // Container contentPane = getContentPane();
	      //p1.setDefaultCloseOperation(EXIT_ON_CLOSE);
	     
	      //p2.setDefaultCloseOperation(EXIT_ON_CLOSE);
	      player1 = new JPanel();
	      Dimension d1= new Dimension(600,350);
	      player1.setPreferredSize(d1);
	      player1.setBackground(Color.LIGHT_GRAY);
	      player1.setLayout(new BorderLayout());
	      player1.setVisible(true);
	      p1left = new JPanel();
	      Dimension d2= new Dimension(125,350);
	      p1left.setPreferredSize(d2);
	      p1left.setBackground(Color.GRAY);
	      p1left.setLayout(new 	GridLayout(2,1));
	     // p1left.add(new JLabel("My power:"),BorderLayout.NORTH);
	      p1right=new JTextArea();
	      Dimension d3= new Dimension(185,350);
	      p1right.setPreferredSize(d3);
	      p1right.setBackground(Color.GRAY);
	      p1right.setLayout(new FlowLayout());
	      player2 = new JPanel();
	      player2.setPreferredSize(new Dimension (125, 250));
	      player2.setLayout(new GridLayout(1,8));
	      player2.setBackground(Color.GREEN);
	      kalamGwaya= new JTextArea();
	      player2.add(kalamGwaya);
	      player1.add(p1left,BorderLayout.WEST);
	      player1.add(p1right,BorderLayout.EAST);
	      player1.setLayout(new GridLayout(0,12));
	      add(player1,BorderLayout.SOUTH);
	      add(player2, BorderLayout.NORTH);
	      WindowDestroyer myListener = new WindowDestroyer();
	      addWindowListener(myListener);
	        this.revalidate();
		    this.repaint();}
	
		public JPanel getPlayer2() {
		return player2;
	}

		public JTextArea getP1right() {
		return p1right;
	}
	public JPanel getP1left() {
		return p1left;
	}
	public JPanel getPlayer1() {
		return player1;
	}
	public JTextArea getKalamGwaya() {
		return kalamGwaya;
	}

		public static void main(String[] args){
	 		view w1 = new view();
	     	w1.setVisible(true);
}
}
