package engine;

//import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.*;

import model.heroes.Hero;
import model.heroes.Hunter;
import model.heroes.Mage;
import model.heroes.Paladin;
import model.heroes.Priest;
import model.heroes.Warlock;

public class Window extends JFrame{
	public Window(){
		  super();
	      setBounds(550,550,400,150);
	      getContentPane().setLayout(new FlowLayout());
	      //JLabel label1 = new JLabel("You are our first player,");
	      //JLabel label2= new JLabel("choose your hero, yala");
	      //getContentPane().add(label1);
	      //getContentPane().add(label2);
	      getContentPane().setBackground(Color.GRAY);
	      WindowDestroyer myListener = new WindowDestroyer();
	      addWindowListener(myListener);
	      }
	  public static void main (String [] args){
		  Window w=new Window();
		  w.setVisible(true);
	  }
	}
