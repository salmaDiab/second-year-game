package engine;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

import exceptions.CannotAttackException;
import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughManaException;
import exceptions.NotSummonedException;
import exceptions.NotYourTurnException;
import exceptions.TauntBypassException;
import model.cards.Card;
import model.cards.minions.Minion;
import model.cards.spells.AOESpell;
import model.cards.spells.FieldSpell;
import model.cards.spells.HeroTargetSpell;
import model.cards.spells.LeechingSpell;
import model.cards.spells.MinionTargetSpell;
import model.cards.spells.Spell;
import model.heroes.Hero;
import model.heroes.Hunter;
import model.heroes.Mage;
import model.heroes.Paladin;
import model.heroes.Priest;
import model.heroes.Warlock;

public class controller extends JFrame implements ActionListener, GameListener {
	private Game g;
	private view v;
	private Window p1 ;
	private Window p2;
	//private Hero x1;
	//private Hero x2;
	private ArrayList<Hero> heroes;
	private ArrayList<Minion> minions;
	private ArrayList<Card> spells;
	//private Hero h2;
	     public controller() {
		        v= new view();
		        heroes = new ArrayList<Hero>();
		        minions=new ArrayList<Minion>();
		        spells= new ArrayList<Card>();
		        p1= new Window();
		        JLabel label1 = new JLabel("You are our first player,");
			      JLabel label2= new JLabel("choose your hero, yala");
			      p1.add(label1);
			      p1.add(label2);
		        p1.setTitle("Player 1");
		        p1.setDefaultCloseOperation(EXIT_ON_CLOSE);
		        this.addButtons(p1);
		        p2 = new Window();
		        JLabel label11 = new JLabel("You are our second player,");
			      JLabel label22= new JLabel("choose your hero, yala");
			      p2.add(label1);
			      p2.add(label2);
		        p2.setTitle("Player 2");
		        p2.setDefaultCloseOperation(EXIT_ON_CLOSE);
		        this.addButtons3(p2);
		        p1.setVisible(true);
		    
			     JButton button1 = new JButton("Use Power");
			     button1.setActionCommand("Use Power");
			     button1.addActionListener(this);
			     JButton button2 = new JButton("End turn");
			     button2.setActionCommand("End turn");
			     button2.addActionListener(this);
				  v.getP1left().add(button1);
				  v.getP1left().add(button2);
				  //addButtons2();
				 v.revalidate();
				  v.repaint();
	     	}

		@Override
	public void onGameOver() {
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		try{
		switch(e.getActionCommand()){
		case "Rexxar1":Hunter h= new Hunter();heroes.add(h);p1.setVisible(false);p2.setVisible(true);break;
		case "Jaina Proudmoore1": Mage h2= new Mage();heroes.add(h2);p1.setVisible(false);p2.setVisible(true);break;
		case "Uther Lightbringer1": Paladin h3= new Paladin();heroes.add(h3);p1.setVisible(false);p2.setVisible(true);break;
		case "Anduin Wrynn1": Priest h4= new Priest();heroes.add(h4);p1.setVisible(false);p2.setVisible(true);break;
		case "Gul'dan1": Warlock h5= new Warlock();heroes.add(h5);p1.setVisible(false);p2.setVisible(true);break;
		}
			switch(e.getActionCommand()){
			case "Rexxar2":Hunter h= new Hunter();heroes.add(h);p2.setVisible(false);StartWindow s= new StartWindow();Hero x=heroes.get(0);Hero x1= heroes.get(1);
			this.g = new Game(x,x1); this.addButtons2(g.getCurrentHero());this.heroHary(g.getCurrentHero());this.addField(g.getCurrentHero(), v.getPlayer1());v.getKalamGwaya().setText("aywa ana el opponent:\n "+g.getOpponent().getName() +  "\nHealth:\n" + g.getOpponent().getCurrentHP() +"\ncurrent Manacrystals: \n"+g.getOpponent().getCurrentManaCrystals()+"\nTotal Manacrystals:\n" +g.getOpponent().getTotalManaCrystals()+ "\nDeck contains:\n"+ g.getOpponent().getDeck().size() +"cards \n Hand contains:\n"+ g.getOpponent().getHand().size()+ "cards.");
			v.getKalamGwaya().setEditable(false);this.addOppField(g.getOpponent(), v.getPlayer2()); break;
			case "Jaina Proudmoore2": Mage h2= new Mage();heroes.add(h2);p2.setVisible(false);StartWindow s2= new StartWindow();Hero x2=heroes.get(0);Hero x22= heroes.get(1);
			this.g = new Game(x2,x22); this.addButtons2(g.getCurrentHero());this.heroHary(g.getCurrentHero());this.addField(g.getCurrentHero(), v.getPlayer1());v.getKalamGwaya().setText("aywa ana el opponent:\n "+g.getOpponent().getName() +  "\nHealth:\n" + g.getOpponent().getCurrentHP() +"\ncurrent Manacrystals: \n"+g.getOpponent().getCurrentManaCrystals()+"\nTotal Manacrystals:\n" +g.getOpponent().getTotalManaCrystals()+ "\nDeck contains:\n"+ g.getOpponent().getDeck().size() +"cards \n Hand contains:\n"+ g.getOpponent().getHand().size()+ "cards.");
			v.getKalamGwaya().setEditable(false);this.addOppField(g.getOpponent(), v.getPlayer2());break;
			case "Uther Lightbringer2": Paladin h3= new Paladin();heroes.add(h3);p2.setVisible(false);StartWindow s3= new StartWindow();Hero x3=heroes.get(0);Hero x33= heroes.get(1);
			this.g = new Game(x3,x33); this.addButtons2(g.getCurrentHero());this.heroHary(g.getCurrentHero());this.addField(g.getCurrentHero(), v.getPlayer1());v.getKalamGwaya().setText("aywa ana el opponent:\n "+g.getOpponent().getName() +  "\nHealth:\n" + g.getOpponent().getCurrentHP() +"\ncurrent Manacrystals: \n"+g.getOpponent().getCurrentManaCrystals()+"\nTotal Manacrystals:\n" +g.getOpponent().getTotalManaCrystals()+ "\nDeck contains:\n"+ g.getOpponent().getDeck().size() +"cards \n Hand contains:\n"+ g.getOpponent().getHand().size()+ "cards.");
			v.getKalamGwaya().setEditable(false);this.addOppField(g.getOpponent(), v.getPlayer2());  break;
			case "Anduin Wrynn2": Priest h4= new Priest();heroes.add(h4);p2.setVisible(false);StartWindow s4= new StartWindow();Hero x4=heroes.get(0);Hero x44= heroes.get(1);
			this.g = new Game(x4,x44);  this.addButtons2(g.getCurrentHero());this.heroHary(g.getCurrentHero());this.addField(g.getCurrentHero(), v.getPlayer1());v.getKalamGwaya().setText("aywa ana el opponent:\n "+g.getOpponent().getName() +  "\nHealth:\n" + g.getOpponent().getCurrentHP() +"\ncurrent Manacrystals: \n"+g.getOpponent().getCurrentManaCrystals()+"\nTotal Manacrystals:\n" +g.getOpponent().getTotalManaCrystals()+ "\nDeck contains:\n"+ g.getOpponent().getDeck().size() +"cards \n Hand contains:\n"+ g.getOpponent().getHand().size()+ "cards.");
			v.getKalamGwaya().setEditable(false);this.addOppField(g.getOpponent(), v.getPlayer2());  break;
			case "Gul'dan2": Warlock h5= new Warlock();heroes.add(h5);p2.setVisible(false);StartWindow s5= new StartWindow();Hero x5=heroes.get(0);Hero x55= heroes.get(1);
			this.g = new Game(x5,x55);  this.addButtons2(g.getCurrentHero());this.heroHary(g.getCurrentHero());this.addField(g.getCurrentHero(), v.getPlayer1());v.getKalamGwaya().setText("aywa ana el opponent:\n "+g.getOpponent().getName() +  "\nHealth:\n" + g.getOpponent().getCurrentHP() +"\ncurrent Manacrystals: \n"+g.getOpponent().getCurrentManaCrystals()+"\nTotal Manacrystals:\n" +g.getOpponent().getTotalManaCrystals()+ "\nDeck contains:\n"+ g.getOpponent().getDeck().size() +"cards \n Hand contains:\n"+ g.getOpponent().getHand().size()+ "cards.");
			v.getKalamGwaya().setEditable(false);this.addOppField(g.getOpponent(), v.getPlayer2()); break;
			}
	
			if(this.checkExistance(e.getActionCommand(), g.getCurrentHero().getHand())){
				if(this.checkExistanceMinion(e.getActionCommand(), this.minions))
				g.getCurrentHero().playMinion(this.getter(e.getActionCommand(), this.minions));
			else
				if(this.checkExistance(e.getActionCommand(), spells)){
					Card x= this.getter2(e.getActionCommand());
					if(x instanceof FieldSpell)
						g.getCurrentHero().castSpell((FieldSpell)x);
					else
						if(x instanceof AOESpell)
							g.getCurrentHero().castSpell((AOESpell)x , g.getOpponent().getField());
						else
							if(x instanceof HeroTargetSpell)
								g.getCurrentHero().castSpell((HeroTargetSpell) x, g.getOpponent());
							else
							if(x instanceof MinionTargetSpell){
								JOptionPane.showMessageDialog(v,"Choose which minion to attack!");
								if(e.getActionCommand().equals("3arkny"))
									g.getCurrentHero().castSpell((MinionTargetSpell)x, this.getter(e.getActionCommand(),g.getOpponent().getField()));
								
							}
							else
								if(x instanceof LeechingSpell){
									JOptionPane.showMessageDialog(v,"Choose which minion to attack!");
									if(e.getActionCommand().equals("3arkny"))
										g.getCurrentHero().castSpell((LeechingSpell)x, this.getter(e.getActionCommand(),g.getOpponent().getField()));}
							}}

			if(this.checkExistanceMinion(e.getActionCommand(), g.getCurrentHero().getField())){
	         	Minion attacker=this.getter(e.getActionCommand(),g.getCurrentHero().getField());
    	         Window choose= new Window();
		         choose.setTitle(" CHOOSE");
	            choose.add(new JLabel("Who do you want to attack?"), BorderLayout.CENTER);
							 choose.setDefaultCloseOperation(EXIT_ON_CLOSE);
							 JButton x1= new JButton("Minion");
							 x1.setActionCommand("Minion");
							 x1.addActionListener(this);
							 JButton x2= new JButton("Hero");
							 x2.setActionCommand("Hero");
							 x2.addActionListener(this);
							 choose.add(x1);
							 choose.add(x2);
							 choose.setVisible(true); 
								if(e.getActionCommand().equals("Hero")){
									g.getCurrentHero().attackWithMinion(attacker, g.getOpponent());
									choose.setVisible(false);}
								else
								 if(e.getActionCommand().equals("Minion")){
									g.getCurrentHero().attackWithMinion(attacker, this.getter(e.getActionCommand(), g.getCurrentHero().getField()));;
								    choose.setVisible(false);}
						 }	
			  if(e.getActionCommand().equals("Use power"))
					 g.getCurrentHero().useHeroPower();
			  
				 if(e.getActionCommand().equals("End turn"))
					 g.getCurrentHero().endTurn();
					 	
			}
		 catch(IOException x){
		System.out.println("ke5");
	   }catch(CloneNotSupportedException y){
		   System.out.println(" ");
	   } catch (NotEnoughManaException | HeroPowerAlreadyUsedException
				| NotYourTurnException | FullHandException | FullFieldException e1) {
		   	e1.printStackTrace(); } catch (CannotAttackException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (TauntBypassException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (InvalidTargetException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (NotSummonedException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}	
	public void addButtons(Window w){
		 String [] heroes ={"Jaina Proudmoore1","Rexxar1","Gul'dan1","Anduin Wrynn1","Uther Lightbringer1"};
	      for(int i=0; i<5;i++){
				JButton heroType= new JButton(heroes[i]);
				heroType.setText(heroes[i]);
				heroType.setVisible(true);
				heroType.setActionCommand(heroes[i]);
				heroType.addActionListener(this);
				//heroType.setBackground(Color.BLACK);
				
				w.add(heroType);
				}
	}
	public void addButtons3(Window w){
		 String [] heroes ={"Jaina Proudmoore2","Rexxar2","Gul'dan2","Anduin Wrynn2","Uther Lightbringer2"};
	      for(int i=0; i<5;i++){
				JButton heroType= new JButton(heroes[i]);
				heroType.setText(heroes[i]);
				heroType.setVisible(true);
				heroType.setActionCommand(heroes[i]);
				heroType.addActionListener(this);
				//heroType.setBackground(Color.BLACK);
				w.add(heroType);
				}
	}
	 public void addButtons2(Hero y){
		  JLabel hand=  new JLabel("HAND:");
		  //hand.setBackground(Color.WHITE);
		  v.getPlayer1().add(hand);
		  for(int i=0; i< y.getHand().size();i++){
		    if (y.getHand().get(i) instanceof Minion){
			 Minion m=(Minion) y.getHand().get(i);
			 String s= "";
			 if(m.isDivine())
				 s+="\n Divine";
			 if(m.isTaunt())
				 s+="\n Taunt";
			 if(!m.isSleeping())
				 s+="\n Charge";
			  JButton minion= new JButton("Click Here!");
			    minion.setLayout(new FlowLayout());
				minion.setActionCommand(m.getName());
				minion.addActionListener(this);
				v.getPlayer1().add(minion);
				JTextArea kalam= new JTextArea();
				kalam.setText(m.getName()+"\n Rarity:"+m.getRarity()+ "\n manacost:"+ m.getManaCost()+"\n Attack:"+m.getAttack()+"\n Health:"+m.getCurrentHP()+ s);
				kalam.setEditable(false);
				minion.add(kalam);
				minions.add(m);
				v.revalidate();
				v.repaint();
				}
		  else
			  if(y.getHand().get(i) instanceof Spell){
				  Card c= y.getHand().get(i);
				  JButton spell= new JButton("click Here!");
				  spell.setLayout(new FlowLayout());
				  JTextArea kalamkteer= new JTextArea();
				  kalamkteer.setText(c.getName()+"\n Rarity:"+c.getRarity()+ "\n manacost:"+ c.getManaCost());
				  kalamkteer.setEditable(false);
				  spell.add(kalamkteer);
					spell.setActionCommand("Play me");
					spell.addActionListener(this);
					v.getPlayer1().add(spell);
					spells.add(c);
					v.revalidate();
					v.repaint();
			  }  }  }
	 public void addField(Hero y, JPanel z){
		  JLabel field=  new JLabel("EL Field yaa");
		  //field.setBackground(Color.WHITE);
		  z.add(field);
		  for(int i=0; i< y.getField().size();i++){
				 Minion m=(Minion) y.getField().get(i);
				 String s= "";
				 String x= "";
				 if(m.isDivine())
					 s+="\n Divine";
				 if(m.isTaunt())
					 s+="\n Taunt";
				 if(!m.isSleeping()){
					 s+="\n Charge";
					 x="You can attack";
					 } else
					 x="You can't attack; I'm sleeping";
				  JButton minion= new JButton();
				  minion.setLayout(new FlowLayout());
					minion.setActionCommand("Attack");
					minion.addActionListener(this);
					z.add(minion);
					JTextArea kalam= new JTextArea();
					kalam.setText(m.getName()+"\n Rarity:"+m.getRarity()+ "\n manacost:"+ m.getManaCost()+"\n Attack:"+m.getAttack()+"\n Health:"+m.getCurrentHP()+ s+ x);
					minion.add(kalam);
					}
		  v.revalidate();
		  v.repaint();  
	 }
	 public void addOppField(Hero y, JPanel z){
		  JLabel field=  new JLabel("EL Field yaa");
		  //field.setBackground(Color.WHITE);
		  z.add(field);
		  for(int i=0; i< y.getField().size();i++){
				 Minion m=(Minion) y.getField().get(i);
				 String s= "";
				 //String x= "";
				 if(m.isDivine())
					 s+="\n Divine";
				 if(m.isTaunt())
					 s+="\n Taunt";
				 if(!m.isSleeping()){
					 s+="\n Charge";
					// x="You can attack";
					// } else
					// x="You can't attack; I'm sleeping";
				  JButton minion= new JButton();
				  minion.setLayout(new FlowLayout());
					minion.setActionCommand("3arkny");
					minion.addActionListener(this);
					z.add(minion);
					JTextArea kalam= new JTextArea();
					kalam.setText(m.getName()+"\n Rarity:"+m.getRarity()+ "\n manacost:"+ m.getManaCost()+"\n Attack:"+m.getAttack()+"\n Health:"+m.getCurrentHP()+ s);
					minion.add(kalam);
					}
		     v.revalidate();
		      v.repaint();  }
	 }
	 public Minion getter(String s, ArrayList<Minion> allMinions) {
			for (int i = 0; i < allMinions.size(); i++) {
				if (allMinions.get(i).getName().equals(s)) 
					return allMinions.get(i);	}
			return null;

		}
	 public Card getter2(String s) {
			for (int i = 0; i < this.spells.size(); i++) {
				if (this.spells.get(i).getName().equals(s)) 
					return this.spells.get(i);	}
			return null;

		}
	 public boolean checkExistance(String s, ArrayList<Card> hand) {
			for (int i = 0; i < hand.size(); i++) {
				if (hand.get(i).getName().equals(s)) {
					return true;
				}
			}
			return false;
		}
	 public boolean checkExistanceMinion(String s, ArrayList<Minion> array) {
			for (int i = 0; i < array.size(); i++) {
				if (array.get(i).getName().equals(s)) {
					return true;
				}
			}
			return false;
		}

	 public void heroHary(Hero y){
		 v.getP1right().setText("My Hero: \n"+ y.getName() +" \nHealth:\n "+y.getCurrentHP() +"\ncurrent Manacrystals: \n"+y.getCurrentManaCrystals()+"\nTotal Manacrystals:\n" +y.getTotalManaCrystals()+ "\nDeck contains:\n"+ g.getCurrentHero().getDeck().size() +"cards");
	v.getP1right().setEditable(false); }
	 
	public static void main (String[] args){
    new controller();
	
	}

}
