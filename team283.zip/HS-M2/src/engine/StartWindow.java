package engine;

import javax.swing.*;

public class StartWindow {
	JFrame f;
	StartWindow(){
		f=new JFrame();
		JOptionPane.showMessageDialog(f,"Let's start the GAME =)");
	}
}
