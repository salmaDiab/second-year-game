package engine;

//import model.heroes.Hero;

public interface GameListener {
	public void onGameOver();
	
}
